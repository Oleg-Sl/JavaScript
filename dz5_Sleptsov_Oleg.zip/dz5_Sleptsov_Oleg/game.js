// 1. Создать функцию, генерирующую шахматную доску. При этом можно использовать любые html-теги по своему желанию.
// Доска должна быть разлинована соответствующим образом, т.е. чередовать черные и белые ячейки.
// Строки должны нумероваться числами от 1 до 8, столбцы – латинскими буквами A, B, C, D, E, F, G, H.
"use strict";

const paramChessBoard = {
  colsCount: 8,
  rowsCount: 8,
  nameColsList: ['a', 'b' ,'c', 'd', 'e', 'f', 'g', 'h'],
};

const chessBoard = {
  paramChessBoard,
  containerElement: document.getElementById('game'),

  drawsMap () {
    // console.log(123);
    for (let row = -1; row <= this.paramChessBoard.rowsCount; row++) {
      // Создаем новую строку.
      const trElem = document.createElement('tr');
      // Добавляем строку в контейнер с игрой.
      this.containerElement.appendChild(trElem);
      for (let col = -1; col <= this.paramChessBoard.colsCount; col++) {
        // Создаем ячейку.
        const cell = document.createElement('td');
        // закрашивание необходимых ячеек
        if ((row + col) % 2 && row !== -1 && row !== this.paramChessBoard.rowsCount && col !== -1 && col !== this.paramChessBoard.rowsCount) {
          cell.style.backgroundColor = '#696969';
        }

        // расстановка фигур 
        cell.innerHTML = this.placementFigures(col, row);
        // покраска белых фигур
        if (this.paintingWhiteFigures(col, row)) {
          console.log(cell.getElementsByTagName('i'));
          cell.getElementsByTagName('i')[0].style.color = 'White';
        }
        

        trElem.appendChild(cell);
        
      }
    }
    
    
    this.fillsMap();
    
  },
  
  
  paintingWhiteFigures(col, row) {
     if ((row === 6 || row == 7) && col !== -1 && col !==8) {
       return true;
     } 
     return false;
  },

  fillsMap () {
    for (let rowName = 1; rowName <= this.paramChessBoard.rowsCount; rowName++) {   
      // заполняет названия столбцов в первой строке    
      this.containerElement.querySelector(`td:nth-child(${rowName + 1})`)
        .innerHTML = this.paramChessBoard.nameColsList[rowName - 1];
      // заполняет названия столбцов в последней строке
      this.containerElement.querySelector('tr:last-child')
        .querySelector(`td:nth-child(${rowName + 1})`)
        .innerHTML = this.paramChessBoard.nameColsList[rowName - 1];
      // заполняет номера строк в первом столбце
      this.containerElement.querySelector(`tr:nth-child(${rowName + 1})`)
        .querySelector(`td:first-child`)
        .innerHTML = 9 - rowName;
        // заполняет номера строк в последнем столбце
      this.containerElement.querySelector(`tr:nth-child(${rowName + 1})`)
        .querySelector(`td:last-child`)
        .innerHTML = 9 - rowName;
    }

  },

  placementFigures (col, row) {
    if (row === 1 || row === 6) {
      return '<i class="fas fa-chess-pawn"></i>';
    } else if (row === 0 || row ===7) {
      switch (col) {
        case 0:
        case 7:
          return '<i class="fas fa-chess-rook"></i>';
        case 1:
        case 6:
          return '<i class="fas fa-chess-knight"></i>';
        case 2:
        case 5:
          return '<i class="fas fa-chess-bishop"></i>';
        case 3:
          return '<i class="fas fa-chess-king"></i>';
        case 4:
          return '<i class="fas fa-chess-queen"></i>';
      }
    } 

    return null;

  },
};


chessBoard.drawsMap();
