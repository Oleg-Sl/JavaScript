"use strict";

/**
 * @property {Object} settings Объект с настройками карзины.
 * @property {number} countElement Количество элементов товара в корзине.
 * @property {number} countElement Суммарная цена товаров в корзине.
 */
const basket = {
  settings: {
    basketClass: 'basket',
    countId: 'basket-count',
    priceId: 'basket-price',
    containerProductClass: '.container',
    buyButtonClass: '.buy-btn',
  },

  countElement: null,
  priceElement: null,

  /**
   * Инициализирует корзину, ставит обработчик события.
   * @param {Object} basketSettings Объект настроек для корзины.
   */
  init(basketSettings = {}) {
    // Записываем настройки, которые передал пользователь в наши настройки.
    Object.assign(this.settings, basketSettings);
    
    // установка начальных данных о корзине
    this.initCountAndPriceBasket ();
    
    // передача данных о корзине на страницу
    this.render();

    // Находим элемент содержащий элементы данных о продуктах и ставим обработчик на этот элемент,
    // при клике на этот элемент вызовем функцию containerClickButton в нашем объекте
    // basket и передадим туда событие MouseEvent, которое случилось.
    document.querySelector(this.settings.containerProductClass).addEventListener('click', event => this.containerClickButton(event));    
  },

   /**
   * Установка начальных данных корзины. Если данные в сессии сохранены то выгрузить их.
   */
  initCountAndPriceBasket () {
    if (sessionStorage['countElement'] || sessionStorage['priceElement']) {
      this.countElement = +sessionStorage.getItem('countElement');
      this.priceElement = +sessionStorage.getItem('priceElement');
      // this.countElement = +sessionStorage['countElement'];
      // this.priceElement = +sessionStorage['priceElement'];
    } else {
      this.countElement = 0;
      this.priceElement = 0;
    }
  },

  /**
   * Обработчик события клика по кнопке покупки товара.
   * @param {MouseEvent} event Событие клики мышью.
   * @param {HTMLElement} event.target Целевой объект, куда был произведен клик.
   */
  containerClickButton (event) {
    if (event.target.tagName !== 'BUTTON') {
      return;
    }

    // добавление товара в корзину 
    this.addProductInBasket(+event.target.dataset.price)

    // изменение данных корзины на странице
    this.render();
  },

  /**
  * добавляет товар в корзину.
  * @param {number} price Ссылка на картинку, которую надо открыть.
  */
  addProductInBasket(price) {
    this.countElement += 1;
    this.priceElement += price;
    sessionStorage.setItem('countElement', this.countElement);
    sessionStorage.setItem('priceElement', this.priceElement);
    // sessionStorage['countElement'] = this.countElement;
    // sessionStorage['priceElement'] = this.priceElement;
  },

  /**
   * Передача данных о корзине на страницу.
   */
  render() {
    document.getElementById(this.settings.countId).innerHTML = this.countElement;
    document.getElementById(this.settings.priceId).innerHTML = this.priceElement;
  }
};


// Инициализируем корзину при загрузке страницы.
window.onload = () => basket.init();


